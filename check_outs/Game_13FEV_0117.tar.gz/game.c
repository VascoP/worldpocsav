#include "main_header.h"

int main (void)
{
	/*sets screen variables and environment*/
	initScreen();
	/*main menu and game loop*/
	initGame();
	endwin();
  
	return EXIT_SUCCESS;
}
