#include "main_header.h"

void initPlayer(char * name, char * password, player * hero)
{
	int i;

	for(i = 0; i < 7; i++)
		hero->skills[i] = 0;
	hero->spelledskills[0] = "Gold";
	hero->spelledskills[1] = "Life";
	hero->spelledskills[2] = "Speed";
	hero->spelledskills[3] = "Wisdom";
	hero->spelledskills[4] = "Agility";
	hero->spelledskills[5] = "Strenght";
	hero->spelledskills[6] = "Resistance";

	hero->name = name;
	hero->password = password;	
	hero->skills[Life] = 100;
}
