#include "main_header.h"

void initGame()
{
	char *choices[] = { "New Game", "Continue Game", "Help", "Exit" };
	int option;

	while(1)
	{
		/*create menu*/
		option = createMenu("--- World of Pocsav ---", choices, arrSize(choices), MARGIN, 0, 0);

		/*choice triggered functions*/
		switch(option)
		{
			/*new game*/
			case 0:	newGame();
					break;
			/*continue game*/
			case 1: continueGame();
					break;
			case 2: help();
					break;
			/*exit*/
			case 3: return;
					break;
		}
	}
}



