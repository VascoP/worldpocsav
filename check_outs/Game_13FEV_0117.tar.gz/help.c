#include "main_header.h"

void help()
{
	WINDOW *helpWin;
	char * truncated;
	char * string = "World of Pocsav is an adventure game where you controll an intrepid warrior in search of gold and fame. Your goal is to survive in the wilderness, defeat enemies, kill beasts and make a name for yourself. Put together a great army, or travel alone, train your skills and gather wealth, the world awaits you!\n";
	int size = strlen(string);

	clear();
	helpWin = newwin(25, 80, 0, 0);
	keypad(helpWin, TRUE);

	wprintw(helpWin, "Help\n\n");
	truncated = truncate(string, size);
	waddstr(helpWin, truncated);
	wrefresh(helpWin);
	wgetch(helpWin);

	delwin(helpWin);
	return;
}

char * truncate(char * string, int size)
{
	int i, pos = 0, j = 0;
	char * out = (char *) malloc((size*2)*sizeof(char));

	for(i = 0; i < size*2; i++)
	{
		if((pos+1) == screenx)
		{
			if((out[(i-1)] >= 'a' && out[(i-1)] >= 'z') || (out[(i-1)] >= 'A' && out[(i-1)] >= 'Z')) 
				out[i] = '-';
			else
				out[i] = ' ';
			pos = 0;
		}
		else
		{
			out[i] = string[j];
			pos++;
			j++;
		}
	}
	out[i++] = '\0';

	return out;
}


