#include "main_header.h"

void newGame()
{
	char pass[11], name[11];
	player hero;

	inputField("Choose name", name, 0);
	inputField("Choose password", pass, 1);	

	initPlayer(name, pass, &hero);
	createRemotePlayer(hero);

	showStats(hero);

}
