#include "main_header.h"

void inputField(char * label, char * string, int password)
{
	char check[11];

	clear();
	refresh();

	curs_set(1);
	echo();
	refresh();

	if(password)
	{
		do
		{
			printw("[3-10] letters long\n");
			printw("%s: \n", label);
			getnstr(string, 10);
			strcpy(check, string);
			printw("Confirmation must match\n");
			printw("Confirm: \n");
			string[0] = '\0';
			getnstr(string, 10);
			clear();
			refresh();
		}
		while((strcmp(check, string) != 0) || strlen(string) < 3);
	}
	else
	{
		do
		{
			printw("[3-10] letters long\n");
			printw("%s: \n", label);
			getnstr(string, 10);		
			clear();
			refresh();
		}
		while(strlen(string) < 3);
	}	

	noecho();
	curs_set(0);	
	clear();
	refresh();
	return;
}


